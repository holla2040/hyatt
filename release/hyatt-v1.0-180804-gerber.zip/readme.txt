This information, board files, assembly instructions and bill of
materials are company confidental.
Not for distribution.

board
    hyatt

version
    1.0

date
    180804

fudicials at
    10,10
    96.88 

2 layer description
    2 layer board
        crc component cream
        plc component side silkscreen
        stc component side solder stop mask
        cmp component side copper
        sol solder side copper
        sts solder side solder stop mask
        pls solder side silkscreen
        crs solder cream

        drd drill data
        dri drill info
        gpi gerber info

2 layer stack up sequence
    top     x.cmp
    bottom  x.sol

contact info
    Craig Hollabaugh
    970 690 4911
    craig@hollabaugh.com


