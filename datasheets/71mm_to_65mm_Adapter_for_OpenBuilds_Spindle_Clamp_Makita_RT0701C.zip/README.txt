                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2496956
71mm to 65mm Adapter for OpenBuilds Spindle Clamp (Makita RT0701C) by scottyorr is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a reduction adapter to fit in the OpenBuilds spindle mount clamp (V3).  It reduces the diameter from 71mm to 65mm, suitable for the Makita RT0701C palm router.

<b>Update (Sept. 4, 2017):</b>  I've now tested and refined the adapter.  It actually fits now. (I also redesigned the clamp so it shouldn't need to be printed with supports.)  I replaced the original files with the new ones.

# Print Settings

Printer: QuorXZ
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: 0.2mm
Infill: 50%

Notes: 
If you have artifacts when trying to print both at the same time, try one at a time.